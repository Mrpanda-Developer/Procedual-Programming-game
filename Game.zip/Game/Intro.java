package Game;
/*
 * This class will display the intro banner and subtitle for the game.
 * 
 */
public class Intro {

    public static void show() {
        String banner =
                "      ██╗ ██████╗        ██╗ ██████╗      \n" +
                "      ██║██╔═══██╗       ██║██╔═══██╗     \n" +
                "      ██║██║   ██║       ██║██║   ██║     \n" +
                " ██   ██║██║   ██║   ██  ██║██║   ██║     \n" +
                " ╚█████╔╝╚██████╔╝   ╚████╔╝╚██████╔╝     \n" +
                "  ╚════╝  ╚═════╝     ╚═══╝  ╚═════╝      \n";

        String subtitle = "              S  t  e  e  l   B  a  l  l   R  u  n\n";

        System.out.println(banner);
        System.out.println(subtitle);
    }
}
